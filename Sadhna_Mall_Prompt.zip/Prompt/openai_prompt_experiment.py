# Text Summarization and Sentiment Analysis with OpenAI API
# Compare direct vs. structured prompts


import openai
import os

sample_text = '''
The recent advancements in artificial intelligence have led to significant improvements in natural language processing. These technologies are now being used in a variety of industries, from healthcare to finance, to automate tasks and provide insights that were previously unattainable. However, there are concerns about the ethical implications and potential job displacement caused by AI systems.'''

def summarize(text, prompt_style):
    if prompt_style == 'direct':
        prompt = f"Summarize the following text:\n{text}"
    else:
        prompt = (
            "You are an expert text summarizer. Read the following passage carefully. "
            "Identify the main points, condense the information, and present a concise summary in 2-3 sentences. "
            f"Text:\n{text}"
        )
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        raise RuntimeError('OPENAI_API_KEY environment variable not set.')
    client = openai.OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )
    return response.choices[0].message.content.strip()

def sentiment(text, prompt_style):
    if prompt_style == 'direct':
        prompt = f"What is the sentiment of the following text?\n{text}"
    else:
        prompt = (
            "You are a sentiment analysis expert. Read the passage below and classify its sentiment as Positive, Negative, or Neutral. "
            "Explain your reasoning in 1-2 sentences.\n"
            f"Text:\n{text}"
        )
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        raise RuntimeError('OPENAI_API_KEY environment variable not set.')
    client = openai.OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )
    return response.choices[0].message.content.strip()

if __name__ == "__main__":
    print("--- Summarization ---")
    print("Direct Prompt:")
    print(summarize(sample_text, 'direct'))
    print("\nStructured Prompt:")
    print(summarize(sample_text, 'structured'))

    print("\n--- Sentiment Analysis ---")
    print("Direct Prompt:")
    print(sentiment(sample_text, 'direct'))
    print("\nStructured Prompt:")
    print(sentiment(sample_text, 'structured'))
